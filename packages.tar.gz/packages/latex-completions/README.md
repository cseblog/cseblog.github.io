# LaTeX Completions for Atom

It's simple enough – Latex Completions takes LaTeX character names such as
`\alpha` and replaces them with unicode characters like `α`.

<div align="center"><img src="https://raw.githubusercontent.com/JunoLab/atom-latex-completions/master/demo.gif" /></div>
