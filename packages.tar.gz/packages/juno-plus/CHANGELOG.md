# 0.13
- Removed overriding tool-bar position or iconsizes
- Bug fixes

## 0.11
* Rewrite codebase in typescript
* Stack icons for saving space
* Colorful buttons
* Many performance optimizations and bug fixes

## 0.10
* new button Debug: Run File
* new button Debug: Step into File
* new button Debug: Run block
* new button Debug: Step into block
* Adds options for enabling "Start Julia Process" Buttons (defaults to false)
* Adds options for enabling "Weave Buttons" (defaults to false)
* Combining fold buttons to a toggle folding button
