// This file is the entry file for iconsets rollup
import "./ionicons/ionicons.css";
import "./font-awesome/font-awesome.css";
import "./foundation/foundation-icons.css";
import "./icomoon/icomoon.css";
import "./devicon/devicon.css";
import "./mdi/materialdesignicons.css";
