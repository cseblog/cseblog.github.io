# uber-juno

This is an Atom package which sets up the Juno IDE. It will install the various Julia-related packages, set some custom config for a great Julia environment, and if possible hook up to any currently-installed Julia binaries for evaluation etc.

See setup.md for instructions.
