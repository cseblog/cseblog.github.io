# Julia Grammar

[![Build Status](https://github.com/JuliaEditorSupport/atom-language-julia/workflows/CI/badge.svg)](https://github.com/JuliaEditorSupport/atom-language-julia/actions?query=workflow%3ACI+branch%3Amaster)

Julia grammar definition for Atom, VSCode, and GitHub.

The source of truth in this repo is `grammars/julia.cson`; `julia.json` and `julia_vscode.json` are automatically generated in a pre-commit hook.

## Atom
Also an Atom package to provide Julia syntax highlighting, snippets, and docstring folding. Originally based off of [JuliaLang/julia.tmBundle](https://github.com/JuliaLang/Julia.tmbundle), merged with new ideas from [language-julia](https://github.com/tpoisot/language-julia/blob/master/README.md).

### Features:

- Syntax highlighting
- Snippets for common Julia keywords and constructs (see `snippets/language-julia.cson`)
- Toggle folding of docstrings

### Installation

Installation happens normally either through `apm install language-julia` or through the install section of the settings tab within Atom.

Note: if you already have a different version of language-julia plugin installed (e.g. [this one](https://github.com/tpoisot/language-julia)), you would need to remove it first using `apm uninstall language-julia`

### Recommended Extras

* The [LaTeX Completions](https://github.com/JunoLab/atom-latex-completions)
  package provides support for unicode characters similarly to the Julia REPL.
* The [Indent Detective](https://github.com/JunoLab/atom-indent-detective) package will help you keep to the style guidelines when working on Base or packages.
* Install [language-markdown](https://atom.io/packages/language-markdown) for syntax highlighting in docstrings.
* Install [atom-language-r](https://atom.io/packages/atom-language-r) for syntax highlighting of R string macros.

### Toggling docstrings

Two Atom commands are provided to toggle all docstrings or the docstring under the cursor: `language-julia:toggle-docstrings` and `language-julia:toggle-all-docstrings`. These are not assigned keys. Here is one example of adding these to keymaps using org-mode style keys:

```
'atom-text-editor[data-grammar="source julia"]:not([mini])':
  'tab':       'language-julia:toggle-docstrings'
  'shift-tab': 'language-julia:toggle-all-docstrings'
```

## Contributing

We love contributors. Here are the steps we have taken to develop on this package:

1. Remove the official install of the package: `apm uninstall language-julia`
2. Clone the repository somewhere we can remember: `git clone git@github.com:JuliaEditorSupport/atom-language-julia.git`
3. Link the cloned package to `~/.atom` (enter the following from the root of the repo directory): `apm link .`
4. Hack away!

When new features are added, you should write specs to show that the package is behaving as expected. To run the specs you need to do the following:

- Make sure you have the library's folder open in the current atom project.
- Then open the command pallete and select `Window: Run package specs`. On OSX this key-binding is `ctrl+cmd+option+p`.

This should open up a new window with the spec results.

### Contributor list

- Everyone who has helped with the [tmBundle](https://github.com/JuliaLang/Julia.tmbundle)
- [See contributors](https://github.com/JuliaEditorSupport/atom-language-julia/graphs/contributors)
