# Juno Manual

This is the (work in progress) user manual for Juno.

* [Installation Instructions](https://github.com/JunoLab/uber-juno/blob/master/setup.md)
* [Workflow](workflow.md) – tips and tricks on using Juno/Julia productively
