# Changelog

## v0.1.4

- Reduced unnecessary fetching from providers on Windows.

## v0.1.3

- Fixed an exception when attempting to log errors.
