# Indent Detective

Indent detective tries to work out the indentation settings of your current file, sublime-style. If it can't get an answer it simply sticks with your defaults, and if it gets it wrong it's easy to change by clicking the indicator in the status bar.

![demo](http://i.imgur.com/j0YFXua.gif)
